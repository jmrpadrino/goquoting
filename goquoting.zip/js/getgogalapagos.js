/*$('#getgog');
$.ajax({
    url : 'http://localhost/orangine/getgogalapagos',
    type: 'POST',
    data: {
        web: document.location,
        userID: userID
    }
})*/