<?php
    // Silence is golden